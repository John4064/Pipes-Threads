var searchData=
[
  ['threadid_0',['threadID',['../structargs.html#a92d29fe90f4ea593b0582678539df433',1,'args']]],
  ['tid_1',['tid',['../structargs.html#aacfa2c4419addb20c8c00cc7d4f2b068',1,'args']]]
];
