var searchData=
[
  ['direcarr_0',['direcArr',['../structargs.html#ae8d8dd1d763f5a9ace9e598e16456ba6',1,'args']]]
];
